﻿namespace kitchenIP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OrdersLb = new System.Windows.Forms.ListBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.quitBtn = new System.Windows.Forms.Button();
            this.serialPortArduino = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // OrdersLb
            // 
            this.OrdersLb.FormattingEnabled = true;
            this.OrdersLb.Location = new System.Drawing.Point(9, 47);
            this.OrdersLb.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.OrdersLb.Name = "OrdersLb";
            this.OrdersLb.Size = new System.Drawing.Size(518, 238);
            this.OrdersLb.TabIndex = 0;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.BackColor = System.Drawing.Color.Transparent;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.titleLbl.Location = new System.Drawing.Point(119, 6);
            this.titleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(442, 46);
            this.titleLbl.TabIndex = 1;
            this.titleLbl.Text = "Capo Supremo Pizzeria";
            // 
            // quitBtn
            // 
            this.quitBtn.BackColor = System.Drawing.Color.Transparent;
            this.quitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quitBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.quitBtn.Image = global::kitchenIP.Properties.Resources._75588239_574488233367148_6902869144618663936_n;
            this.quitBtn.Location = new System.Drawing.Point(475, 12);
            this.quitBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.quitBtn.Name = "quitBtn";
            this.quitBtn.Size = new System.Drawing.Size(50, 25);
            this.quitBtn.TabIndex = 2;
            this.quitBtn.Text = "Quit";
            this.quitBtn.UseVisualStyleBackColor = false;
            this.quitBtn.Click += new System.EventHandler(this.quitBtn_Click);
            // 
            // serialPortArduino
            // 
            this.serialPortArduino.PortName = "COM8";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::kitchenIP.Properties.Resources._75588239_574488233367148_6902869144618663936_n;
            this.ClientSize = new System.Drawing.Size(749, 292);
            this.Controls.Add(this.quitBtn);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.OrdersLb);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Kitchen ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox OrdersLb;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Button quitBtn;
        private System.IO.Ports.SerialPort serialPortArduino;
    }
}

